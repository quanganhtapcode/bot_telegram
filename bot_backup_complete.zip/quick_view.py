#!/usr/bin/env python3
"""
Script xem nhanh dữ liệu quan trọng trong database
"""

import sqlite3
import os

def quick_view():
    db_path = "bot.db"
    
    if not os.path.exists(db_path):
        print("❌ Không tìm thấy bot.db")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print("🔍 **XEM NHANH DATABASE**\n")
        
        # 1. Users
        cursor.execute("SELECT COUNT(*) FROM users")
        user_count = cursor.fetchone()[0]
        print(f"👥 **Users: {user_count}**")
        
        if user_count > 0:
            cursor.execute("SELECT name, tg_user_id, last_seen FROM users LIMIT 3")
            users = cursor.fetchall()
            for user in users:
                print(f"  • {user[0]} (ID: {user[1]}) - Cuối: {user[2]}")
        print()
        
        # 2. Wallets
        cursor.execute("SELECT COUNT(*) FROM user_wallets")
        wallet_count = cursor.fetchone()[0]
        print(f"💳 **Wallets: {wallet_count}**")
        
        if wallet_count > 0:
            cursor.execute("SELECT currency, current_balance FROM user_wallets")
            wallets = cursor.fetchall()
            for wallet in wallets:
                print(f"  • {wallet[0]}: {wallet[1]:,}")
        print()
        
        # 3. Personal Expenses
        cursor.execute("SELECT COUNT(*) FROM personal_expenses")
        expense_count = cursor.fetchone()[0]
        print(f"🧾 **Personal Expenses: {expense_count}**")
        
        if expense_count > 0:
            cursor.execute("SELECT amount, currency, note, created_at FROM personal_expenses ORDER BY created_at DESC LIMIT 3")
            expenses = cursor.fetchall()
            for expense in expenses:
                print(f"  • {expense[0]:,} {expense[1]} - {expense[2]} ({expense[3][:10]})")
        print()
        
        # 4. Bank Accounts
        cursor.execute("SELECT COUNT(*) FROM bank_accounts")
        bank_count = cursor.fetchone()[0]
        print(f"🏛️ **Bank Accounts: {bank_count}**")
        
        if bank_count > 0:
            cursor.execute("SELECT bank_name, account_number, account_name FROM bank_accounts")
            banks = cursor.fetchall()
            for bank in banks:
                print(f"  • {bank[0]} - {bank[1]} ({bank[2]})")
        print()
        
        # 5. Exchange Rates
        cursor.execute("SELECT COUNT(*) FROM exchange_rates")
        rate_count = cursor.fetchone()[0]
        print(f"💱 **Exchange Rates: {rate_count}**")
        
        if rate_count > 0:
            cursor.execute("SELECT from_currency, to_currency, rate FROM exchange_rates")
            rates = cursor.fetchall()
            for rate in rates:
                print(f"  • {rate[0]}/{rate[1]}: {rate[2]}")
        print()
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Lỗi: {e}")

if __name__ == "__main__":
    quick_view()
