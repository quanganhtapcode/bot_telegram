# 🚀 HƯỚNG DẪN DEPLOY TELEGRAM BOT LÊN AWS EC2

## 📋 **MÔ TẢ DỰ ÁN**
Telegram Bot quản lý tài chính cá nhân và nhóm với các tính năng:
- 💰 Quản lý ví đa tiền tệ (TWD, USD, VND, EUR)
- 🧾 Ghi chép chi tiêu cá nhân và nhóm
- 🏛️ Tích hợp VietQR để nhận chuyển khoản
- 📊 Theo dõi nợ và thanh toán
- 🔄 Tự động quy đổi tỷ giá

## 🛠️ **YÊU CẦU HỆ THỐNG**
- **OS**: Ubuntu 20.04/22.04 LTS
- **Python**: 3.10+
- **RAM**: Tối thiểu 1GB
- **Storage**: Tối thiểu 10GB
- **Network**: Có kết nối internet

## 📁 **CẤU TRÚC THƯ MỤC**
```
bot/
├── main.py                 # File chính của bot
├── config.py              # Cấu hình bot
├── db.py                  # Database operations
├── models.py              # Data models
├── requirements.txt       # Python dependencies
├── bot_manager.sh         # Script quản lý bot trên EC2
├── setup_ec2.sh          # Script setup tự động
├── services/              # Các service (VietQR, currency)
│   ├── __init__.py
│   ├── vietqr.py
│   ├── currency.py
│   ├── deduct.py
│   ├── notifications.py
│   ├── settlement.py
│   └── vietqr.py
├── handlers/              # Message handlers
│   ├── __init__.py
│   ├── callbacks.py
│   ├── commands.py
│   └── messages.py
└── keyboards.py           # Inline keyboard layouts
```

## 🚀 **BƯỚC 1: CHUẨN BỊ TRÊN WINDOWS**

### **1.1. Tải file key.pem từ AWS Console**
- Vào AWS Console → EC2 → Key Pairs
- Tải file key.pem về `C:\Users\PC\Downloads\`

### **1.2. Cập nhật IP EC2 trong deploy script**
```cmd
# Mở file deploy_simple.bat
# Thay đổi IP: set EC2_IP=YOUR_EC2_IP_HERE
```

### **1.3. Chạy script deploy**
```cmd
deploy_simple.bat
```

## 🔧 **BƯỚC 2: KẾT NỐI EC2**

### **2.1. Kết nối SSH**
```bash
ssh -i "C:\Users\PC\Downloads\key.pem" ubuntu@YOUR_EC2_IP
```

### **2.2. Vào thư mục bot**
```bash
cd /home/ubuntu/bot
ls -la
```

## 🐍 **BƯỚC 3: CÀI ĐẶT PYTHON 3.10**

### **3.1. Cập nhật hệ thống**
```bash
sudo apt update
sudo apt upgrade -y
```

### **3.2. Cài đặt Python 3.10**
```bash
sudo apt install -y python3.10 python3.10-pip python3.10-venv python3.10-dev
```

### **3.3. Cài đặt các gói cần thiết**
```bash
sudo apt install -y git curl wget unzip tmux
```

## 🌍 **BƯỚC 4: TẠO MÔI TRƯỜNG ẢO**

### **4.1. Tạo môi trường ảo**
```bash
cd /home/ubuntu/bot
python3.10 -m venv .venv
```

### **4.2. Kích hoạt môi trường**
```bash
source .venv/bin/activate
```

### **4.3. Kiểm tra version**
```bash
python --version
pip --version
```

## 📚 **BƯỚC 5: CÀI ĐẶT THƯ VIỆN**

### **5.1. Nâng cấp pip**
```bash
pip install --upgrade pip
```

### **5.2. Cài đặt từ requirements.txt**
```bash
pip install -r requirements.txt
```

### **5.3. Cài đặt thủ công (nếu cần)**
```bash
pip install python-telegram-bot==21.* aiosqlite python-decimal asyncio
```

### **5.4. Kiểm tra đã cài đầy đủ**
```bash
pip list
```

## ⚙️ **BƯỚC 6: TẠO FILE CẤU HÌNH**

### **6.1. Tạo file .env**
```bash
cat > .env << 'EOF'
BOT_TOKEN=YOUR_BOT_TOKEN_HERE
ADMIN_USER_ID=YOUR_TELEGRAM_USER_ID
DATABASE_URL=bot.db
LOG_LEVEL=INFO
EOF
```

### **6.2. Kiểm tra file**
```bash
cat .env
```

## 🔐 **BƯỚC 7: THIẾT LẬP QUYỀN**

### **7.1. Thiết lập quyền script**
```bash
chmod +x bot_manager.sh
```

### **7.2. Thiết lập quyền sở hữu**
```bash
sudo chown -R ubuntu:ubuntu /home/ubuntu/bot
```

## 🧪 **BƯỚC 8: TEST BOT**

### **8.1. Kiểm tra syntax**
```bash
python -m py_compile main.py
echo "Syntax OK!"
```

### **8.2. Test import modules**
```bash
python -c "import telegram; print('Telegram OK')"
python -c "import aiosqlite; print('SQLite OK')"
python -c "import main; print('Main OK')"
```

### **8.3. Chạy bot test**
```bash
python main.py
```

## 🚀 **BƯỚC 9: CHẠY BOT VỚI TMUX**

### **9.1. Tạo tmux session**
```bash
tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py'
```

### **9.2. Kiểm tra session**
```bash
tmux list-sessions
```

### **9.3. Vào session xem logs**
```bash
tmux attach-session -t bot
```

### **9.4. Thoát session (giữ bot chạy)**
- Nhấn: `Ctrl+B` rồi `D`

## 🎯 **BƯỚC 10: KIỂM TRA HOẠT ĐỘNG**

### **10.1. Kiểm tra process**
```bash
ps aux | grep python
```

### **10.2. Kiểm tra logs**
```bash
tail -f bot.log
```

### **10.3. Test bot trên Telegram**
- Gửi `/start` cho bot
- Kiểm tra phản hồi

## 🛠️ **LỆNH QUẢN LÝ BOT**

### **Start bot**
```bash
tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py'
```

### **Stop bot**
```bash
tmux kill-session -t bot
```

### **Restart bot**
```bash
tmux kill-session -t bot && tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py'
```

### **Check status**
```bash
tmux list-sessions
```

### **View logs**
```bash
tmux attach-session -t bot
```

## 🔄 **SỬ DỤNG BOT_MANAGER.SH**

### **Start**
```bash
./bot_manager.sh start
```

### **Stop**
```bash
./bot_manager.sh stop
```

### **Restart**
```bash
./bot_manager.sh restart
```

### **Status**
```bash
./bot_manager.sh status
```

### **Logs**
```bash
./bot_manager.sh logs
```

### **Update**
```bash
./bot_manager.sh update
```

### **Backup**
```bash
./bot_manager.sh backup
```

## 🚨 **XỬ LÝ LỖI THƯỜNG GẶP**

### **Lỗi 1: Permission denied**
```bash
sudo chown -R ubuntu:ubuntu /home/ubuntu/bot
chmod +x bot_manager.sh
```

### **Lỗi 2: Python không tìm thấy**
```bash
which python3.10
python3.10 --version
sudo ln -s /usr/bin/python3.10 /usr/bin/python
```

### **Lỗi 3: Module không tìm thấy**
```bash
source .venv/bin/activate
pip install -r requirements.txt
```

### **Lỗi 4: Tmux session bị exit**
```bash
# Chạy trực tiếp để xem lỗi
python main.py

# Tạo session với logging
tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py > bot.log 2>&1'
```

## 📱 **CÁCH LẤY BOT_TOKEN**

### **Bước 1: Tạo bot với @BotFather**
1. Mở Telegram, tìm @BotFather
2. Gửi `/newbot`
3. Đặt tên bot
4. Đặt username (phải kết thúc bằng 'bot')
5. Copy BOT_TOKEN

### **Bước 2: Lấy Admin User ID**
1. Gửi tin nhắn cho @userinfobot
2. Copy User ID

## 🔒 **BẢO MẬT**

### **1. Không chia sẻ file key.pem**
### **2. Không commit .env lên git**
### **3. Sử dụng Security Groups trên AWS**
### **4. Cập nhật hệ thống thường xuyên**

## 📞 **HỖ TRỢ**

Nếu gặp vấn đề:
1. Kiểm tra logs: `tail -f bot.log`
2. Kiểm tra process: `ps aux | grep python`
3. Kiểm tra tmux: `tmux list-sessions`
4. Restart bot: `./bot_manager.sh restart`

## 🎉 **CHÚC MỪNG!**

Bot đã được deploy thành công lên EC2 và sẽ chạy 24/7 với tmux!

---
**Lưu ý**: Bot sẽ tự động khởi động lại khi có lỗi và sẽ tiếp tục hoạt động ngay cả khi bạn thoát SSH.
