#!/usr/bin/env python3
"""
Script để xem dữ liệu trong database bot.db
"""

import sqlite3
import os
from datetime import datetime

def view_database():
    db_path = "bot.db"
    
    if not os.path.exists(db_path):
        print(f"❌ Không tìm thấy file database: {db_path}")
        return
    
    print("🔍 **XEM DỮ LIỆU DATABASE**\n")
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Lấy danh sách các bảng
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = cursor.fetchall()
        
        print(f"📋 **Các bảng trong database:**")
        for table in tables:
            print(f"  • {table[0]}")
        print()
        
        # Xem dữ liệu từng bảng
        for table in tables:
            table_name = table[0]
            print(f"📊 **Bảng: {table_name}**")
            print("-" * 50)
            
            try:
                # Đếm số record
                cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
                count = cursor.fetchone()[0]
                print(f"Số record: {count}")
                
                if count > 0:
                    # Xem cấu trúc bảng
                    cursor.execute(f"PRAGMA table_info({table_name})")
                    columns = cursor.fetchall()
                    column_names = [col[1] for col in columns]
                    print(f"Các cột: {', '.join(column_names)}")
                    
                    # Xem 5 record đầu tiên
                    cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
                    rows = cursor.fetchall()
                    
                    print("\n**5 record đầu tiên:**")
                    for i, row in enumerate(rows, 1):
                        print(f"  {i}. {row}")
                    
                    if count > 5:
                        print(f"  ... và {count - 5} record khác")
                
            except Exception as e:
                print(f"  ❌ Lỗi khi xem bảng {table_name}: {e}")
            
            print("\n")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Lỗi khi kết nối database: {e}")

def view_specific_table(table_name):
    """Xem dữ liệu của một bảng cụ thể"""
    db_path = "bot.db"
    
    if not os.path.exists(db_path):
        print(f"❌ Không tìm thấy file database: {db_path}")
        return
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        print(f"📊 **Xem bảng: {table_name}**")
        print("-" * 50)
        
        # Kiểm tra bảng có tồn tại không
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table_name,))
        if not cursor.fetchone():
            print(f"❌ Bảng '{table_name}' không tồn tại!")
            return
        
        # Đếm số record
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        count = cursor.fetchone()[0]
        print(f"Số record: {count}")
        
        if count > 0:
            # Xem cấu trúc bảng
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            column_names = [col[1] for col in columns]
            print(f"Các cột: {', '.join(column_names)}")
            
            # Xem tất cả record
            cursor.execute(f"SELECT * FROM {table_name}")
            rows = cursor.fetchall()
            
            print(f"\n**Tất cả {count} record:**")
            for i, row in enumerate(rows, 1):
                print(f"  {i}. {row}")
        
        conn.close()
        
    except Exception as e:
        print(f"❌ Lỗi: {e}")

if __name__ == "__main__":
    print("🔍 **TOOL XEM DATABASE**\n")
    print("1. Xem tất cả bảng")
    print("2. Xem bảng cụ thể")
    print("3. Thoát")
    
    while True:
        choice = input("\nChọn (1-3): ").strip()
        
        if choice == "1":
            view_database()
        elif choice == "2":
            table_name = input("Nhập tên bảng: ").strip()
            if table_name:
                view_specific_table(table_name)
        elif choice == "3":
            print("👋 Tạm biệt!")
            break
        else:
            print("❌ Lựa chọn không hợp lệ!")
