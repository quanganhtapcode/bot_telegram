#!/bin/bash

echo "🚀 SETUP TELEGRAM BOT ON EC2"
echo "=============================="
echo

# Kiểm tra quyền sudo
if [ "$EUID" -ne 0 ]; then
    echo "❌ Vui lòng chạy với quyền sudo"
    exit 1
fi

echo "📋 Cập nhật hệ thống..."
apt update && apt upgrade -y

echo "🐍 Cài đặt Python 3.11..."
apt install -y python3.11 python3.11-pip python3.11-venv python3.11-dev

echo "📦 Cài đặt các gói cần thiết..."
apt install -y git curl wget unzip

echo "🔧 Tạo môi trường ảo..."
cd /home/ubuntu/bot
python3.11 -m venv .venv

echo "📚 Cài đặt thư viện Python..."
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt

echo "🔐 Thiết lập quyền..."
chown -R ubuntu:ubuntu /home/ubuntu/bot
chmod +x /home/ubuntu/bot/bot_manager.sh

echo "📝 Tạo file .env template..."
cat > /home/ubuntu/bot/.env.template << EOF
# Telegram Bot Configuration
BOT_TOKEN=your_bot_token_here

# Admin User ID (get from @userinfobot)
ADMIN_USER_ID=your_admin_user_id

# Database (SQLite)
DATABASE_URL=bot.db

# Logging
LOG_LEVEL=INFO
EOF

echo "✅ Setup hoàn tất!"
echo
echo "📋 Bước tiếp theo:"
echo "1. Tạo file .env: cp .env.template .env"
echo "2. Chỉnh sửa .env với BOT_TOKEN thật"
echo "3. Chạy bot: ./bot_manager.sh start"
echo
echo "🔍 Lệnh hữu ích:"
echo "- Trạng thái: ./bot_manager.sh status"
echo "- Logs: ./bot_manager.sh logs"
echo "- Dừng: ./bot_manager.sh stop"
echo "- Khởi động lại: ./bot_manager.sh restart"
