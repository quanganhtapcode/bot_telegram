# ✅ DEPLOY CHECKLIST - TELEGRAM BOT

## 🚀 **TRƯỚC KHI DEPLOY**

- [ ] **File key.pem** đã tải về `C:\Users\PC\Downloads\`
- [ ] **IP EC2** đã cập nhật trong `deploy_simple.bat`
- [ ] **Bot Token** đã có sẵn
- [ ] **Admin User ID** đã có sẵn
- [ ] **Tất cả file** đã được commit và save

## 📤 **BƯỚC 1: DEPLOY CODE**

- [ ] Chạy `deploy_simple.bat` hoặc `deploy_optimized.bat`
- [ ] Kiểm tra upload thành công
- [ ] Không có lỗi SCP

## 🔧 **BƯỚC 2: KẾT NỐI EC2**

- [ ] SSH vào EC2: `ssh -i "key.pem" ubuntu@IP`
- [ ] Vào thư mục: `cd /home/ubuntu/bot`
- [ ] Kiểm tra files: `ls -la`

## 🐍 **BƯỚC 3: CÀI PYTHON 3.10**

- [ ] Cập nhật hệ thống: `sudo apt update && sudo apt upgrade -y`
- [ ] Cài Python 3.10: `sudo apt install -y python3.10 python3.10-pip python3.10-venv python3.10-dev`
- [ ] Cài tmux: `sudo apt install -y tmux`
- [ ] Kiểm tra: `python3.10 --version`

## 🌍 **BƯỚC 4: MÔI TRƯỜNG ẢO**

- [ ] Tạo môi trường: `python3.10 -m venv .venv`
- [ ] Kích hoạt: `source .venv/bin/activate`
- [ ] Kiểm tra: `python --version` và `pip --version`

## 📚 **BƯỚC 5: CÀI THƯ VIỆN**

- [ ] Nâng cấp pip: `pip install --upgrade pip`
- [ ] Cài requirements: `pip install -r requirements.txt`
- [ ] Cài thủ công nếu cần: `pip install python-telegram-bot==21.* aiosqlite python-decimal asyncio`
- [ ] Kiểm tra: `pip list`

## ⚙️ **BƯỚC 6: CẤU HÌNH**

- [ ] Tạo .env: `cp .env.template .env`
- [ ] Chỉnh sửa .env với BOT_TOKEN thật
- [ ] Kiểm tra: `cat .env`

## 🔐 **BƯỚC 7: QUYỀN**

- [ ] Thiết lập quyền: `chmod +x bot_manager.sh`
- [ ] Quyền sở hữu: `sudo chown -R ubuntu:ubuntu /home/ubuntu/bot`

## 🧪 **BƯỚC 8: TEST**

- [ ] Kiểm tra syntax: `python -m py_compile main.py`
- [ ] Test import: `python -c "import telegram; print('OK')"`
- [ ] Chạy test: `python main.py` (để xem lỗi nếu có)

## 🚀 **BƯỚC 9: CHẠY BOT**

- [ ] Tạo tmux: `tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py'`
- [ ] Kiểm tra: `tmux list-sessions`
- [ ] Vào session: `tmux attach-session -t bot`

## 🎯 **BƯỚC 10: KIỂM TRA**

- [ ] Bot đang chạy: `ps aux | grep python`
- [ ] Logs: `tail -f bot.log`
- [ ] Test Telegram: Gửi `/start` cho bot
- [ ] Bot phản hồi OK

## 🛠️ **SAU KHI HOÀN THÀNH**

- [ ] Bot chạy 24/7 với tmux
- [ ] Có thể thoát SSH mà bot vẫn chạy
- [ ] Có thể restart: `tmux kill-session -t bot && tmux new-session -d -s bot 'cd /home/ubuntu/bot && source .venv/bin/activate && python main.py'`
- [ ] Có thể xem logs: `tmux attach-session -t bot`

## 🚨 **NẾU CÓ LỖI**

- [ ] Kiểm tra logs: `tail -f bot.log`
- [ ] Kiểm tra process: `ps aux | grep python`
- [ ] Kiểm tra tmux: `tmux list-sessions`
- [ ] Restart: `./bot_manager.sh restart`

---
**Lưu ý**: Đánh dấu ✅ cho mỗi bước đã hoàn thành để theo dõi tiến độ!
